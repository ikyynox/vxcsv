#!/usr/bin/env bash
# Cek & update Chrome di sidecar fp-sidecar. Jalankan di VPS (root).
#   bash /opt/fp-sidecar/update-chrome.sh            cek, kalau ada versi stable lebih baru => rebuild (hanya saat sepi)
#   bash /opt/fp-sidecar/update-chrome.sh --check    cek saja, tidak mengubah apa pun
#   bash /opt/fp-sidecar/update-chrome.sh --force    update walau versi sama / walau ada sesi aktif
set -uo pipefail
DEST="/opt/fp-sidecar"; NAME="fp-sidecar"; PORT=9222
LOG="/var/log/fp-sidecar-update.log"
MODE="${1:-auto}"
log() { printf '%s %s\n' "$(date '+%F %T')" "$*" | tee -a "$LOG"; }
[ "$(id -u)" -eq 0 ] || { echo "Jalankan sebagai root"; exit 1; }
exec 9>/var/lock/fp-sidecar-update.lock; flock -n 9 || { log "update lain sedang jalan, keluar"; exit 0; }
if docker compose version >/dev/null 2>&1; then DC="docker compose"; else DC="docker-compose"; fi
TOKEN="$(grep -E '^SIDECAR_TOKEN=' "$DEST/.env" | tail -n1 | cut -d= -f2- | tr -d '\r"')"
[ -n "$TOKEN" ] || { log "SIDECAR_TOKEN tidak ketemu di $DEST/.env"; exit 1; }
api() { docker exec "$NAME" curl -s -m "${2:-20}" ${3:+-X "$3"} -H "Authorization: Bearer $TOKEN" "http://localhost:$PORT$1"; }

docker ps --format '{{.Names}}' | grep -qx "$NAME" || { log "container $NAME tidak jalan"; exit 1; }
IMG="$(docker inspect "$NAME" --format '{{.Config.Image}}')"
CUR="$(docker exec "$NAME" dpkg-query -W -f='${Version}' google-chrome-stable 2>/dev/null)"
# versi stable terbaru di repo Google = persis yang akan terpasang saat build (dicek dari container sementara, lewat jaringan VPS, bukan proxy residential)
NEW="$(docker run --rm -u 0 --entrypoint sh "$IMG" -c 'apt-get update -qq >/dev/null 2>&1; apt-cache policy google-chrome-stable | awk "/Candidate:/{print \$2}"' 2>/dev/null)"
[ -n "$CUR" ] && [ -n "$NEW" ] && [ "$NEW" != "(none)" ] || { log "gagal baca versi (terpasang='$CUR' terbaru='$NEW')"; exit 1; }
log "Chrome terpasang: $CUR | stable terbaru: $NEW"
if [ "$CUR" = "$NEW" ] && [ "$MODE" != "--force" ]; then log "sudah terbaru, tidak ada yang dilakukan"; exit 0; fi
[ "$MODE" = "--check" ] && { log "ADA update ($CUR -> $NEW). Jalankan tanpa --check untuk update."; exit 0; }

# Tunggu sepi: /ensure lewat antrean internal sidecar (menunggu rotasi yang sedang jalan), lalu pastikan tidak ada koneksi Chrome aktif
if [ "$MODE" != "--force" ]; then
  api /ensure 170 POST >/dev/null
  for i in 1 2 3; do
    A="$(api /status | grep -o '"activeWs":[0-9]*' | cut -d: -f2)"
    if [ "${A:-1}" != "0" ]; then log "masih ada sesi browser aktif (activeWs=${A:-?}), update ditunda ke jadwal berikutnya"; exit 0; fi
    sleep 20
  done
fi

log "Update $CUR -> $NEW: build (beberapa menit)"
docker tag "$IMG" "$IMG:prev" 2>/dev/null
if ! ( cd "$DEST" && $DC build --no-cache ) >>"$LOG" 2>&1; then log "BUILD GAGAL. Container lama tetap jalan, tidak ada yang berubah."; exit 1; fi
( cd "$DEST" && $DC up -d ) >>"$LOG" 2>&1
log "menunggu sidecar siap (maks 10 menit)"
OK=0; for i in $(seq 1 120); do
  docker logs --since 10m "$NAME" 2>&1 | grep -q ' siap: ' && { OK=1; break; }; sleep 5; done
if [ "$OK" -ne 1 ]; then
  log "sidecar baru TIDAK siap, rollback ke image lama"
  docker tag "$IMG:prev" "$IMG" && ( cd "$DEST" && $DC up -d ) >>"$LOG" 2>&1
  exit 1
fi
log "SELESAI. Chrome sekarang: $(docker exec "$NAME" dpkg-query -W -f='${Version}' google-chrome-stable). IP residential berganti karena session baru."
