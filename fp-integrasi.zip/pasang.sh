#!/usr/bin/env bash
# ============================================================
# pasang.sh — pasang sidecar FastProxy otomatis (jalankan di SSH VPS sebagai root)
#   unzip fp-integrasi.zip && bash pasang.sh
# Bisa diulang kapan saja (aman): rebuild + cek ulang.
# Opsional lewat env (lewati pertanyaan): FP_USER_TEMPLATE, FP_PASS, SIDECAR_TOKEN
# ============================================================
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/fp-sidecar"
PATCH="$HERE/bot-patch"
DEST="/opt/fp-sidecar"
NET_DEFAULT="pterodactyl_nw"
PORT=9222

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m  [OK]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m  [!]\033[0m %s\n' "$*"; }
die()  { printf '\n\033[1;31m  [GAGAL]\033[0m %s\n' "$*" >&2; exit 1; }
ask()  { local v; read -rp "$1" v </dev/tty || v=""; printf '%s' "$v"; }
yes()  { local a; a="$(ask "$1 [Y/n] ")"; [[ -z "$a" || "$a" =~ ^[YyOo] ]]; }

# ---------- 1. Cek awal ----------
say "Cek awal"
[ "$(id -u)" -eq 0 ] || die "Jalankan sebagai root (sudo bash pasang.sh)."
for f in Dockerfile docker-compose.yml control.js; do [ -f "$SRC/$f" ] || die "File $SRC/$f tidak ada. Jalankan dari folder hasil unzip fp-integrasi.zip."; done
command -v docker >/dev/null 2>&1 || die "Docker tidak terpasang."
if docker compose version >/dev/null 2>&1; then DC="docker compose"
elif command -v docker-compose >/dev/null 2>&1; then DC="docker-compose"
else
  warn "docker compose belum ada, mencoba memasang..."
  apt-get install -y docker-compose-plugin >/dev/null 2>&1 || true
  docker compose version >/dev/null 2>&1 || die "Gagal memasang docker compose. Pasang manual: apt install docker-compose-plugin"
  DC="docker compose"
fi
ok "docker + compose siap ($DC)"
[ -e /dev/net/tun ] || { modprobe tun 2>/dev/null || true; }
[ -e /dev/net/tun ] || die "/dev/net/tun tidak ada di host (kernel tanpa modul tun)."
ok "/dev/net/tun ada"

# ---------- 2. Jaringan Pterodactyl ----------
say "Jaringan Pterodactyl"
NET="$NET_DEFAULT"
if ! docker network inspect "$NET" >/dev/null 2>&1; then
  warn "Jaringan $NET tidak ditemukan. Daftar jaringan:"
  docker network ls
  NET="$(ask 'Ketik NAMA jaringan Pterodactyl dari daftar di atas: ')"
  docker network inspect "$NET" >/dev/null 2>&1 || die "Jaringan '$NET' tidak ada."
fi
IPAM="$(docker network inspect "$NET" --format '{{range .IPAM.Config}}{{.Subnet}} {{.Gateway}}{{"\n"}}{{end}}' | awk '$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\// {print; exit}')"
SUBNET="$(awk '{print $1}' <<<"$IPAM")"; GATEWAY="$(awk '{print $2}' <<<"$IPAM")"
[ -n "$SUBNET" ] || die "Tidak menemukan subnet IPv4 di jaringan $NET."
ok "Jaringan $NET  subnet $SUBNET  gateway $GATEWAY"

# IP tetap sidecar: pakai yang lama kalau container sudah ada, kalau belum cari yang kosong
SIDE_IP="$(docker inspect fp-sidecar --format "{{with index .NetworkSettings.Networks \"$NET\"}}{{.IPAddress}}{{end}}" 2>/dev/null || true)"
if [ -z "$SIDE_IP" ]; then
  USED="$(docker network inspect "$NET" --format '{{range .Containers}}{{.IPv4Address}} {{end}}')"
  command -v python3 >/dev/null 2>&1 || die "python3 dibutuhkan untuk memilih IP kosong (apt install python3)."
  SIDE_IP="$(python3 - "$SUBNET" "$GATEWAY" "$USED" <<'PY'
import sys, ipaddress
net = ipaddress.ip_network(sys.argv[1], strict=False)
used = {u.split('/')[0] for u in sys.argv[3].split()} | {sys.argv[2]}
for off in list(range(250, 200, -1)) + list(range(100, 2, -1)):
    ip = net.network_address + off
    if ip in net and ip != net.broadcast_address and str(ip) not in used:
        print(ip); break
PY
)"
fi
[ -n "$SIDE_IP" ] || die "Tidak menemukan IP kosong di $SUBNET."
ok "IP sidecar: $SIDE_IP"

# ---------- 3. Konfigurasi (.env sidecar) ----------
say "Konfigurasi FastProxy"
mkdir -p "$DEST"
KEEP=0
if [ -f "$DEST/.env" ]; then
  warn "$DEST/.env sudah ada."
  yes "Pakai konfigurasi lama?" && KEEP=1
fi
if [ "$KEEP" -eq 0 ]; then
  TOKEN="${SIDECAR_TOKEN:-}"
  [ -n "$TOKEN" ] || TOKEN="$(openssl rand -hex 24 2>/dev/null || head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  # Semua isian TAMPIL di layar (tidak disembunyikan) supaya salah paste langsung kelihatan, lalu dikonfirmasi.
  while true; do
    TPL="${FP_USER_TEMPLATE:-}"; PASS="${FP_PASS:-}"
    if [ -z "$TPL" ]; then
      echo "Dari Proxy Generator FastProxy (SOCKS5), tulis USERNAME dengan session ID diganti {sid}"
      echo "dan kode negara diganti {country}. Contoh: akunmu-country-{country}-session-{sid}"
      TPL="$(ask 'FP_USER_TEMPLATE: ')"
    fi
    [[ "$TPL" == *"{sid}"* ]] || { warn "Template harus mengandung {sid}. Ulangi."; FP_USER_TEMPLATE=""; FP_PASS=""; continue; }
    [ -n "$PASS" ] || PASS="$(ask 'Password FastProxy: ')"
    [ -n "$PASS" ] || { warn "Password kosong. Ulangi."; FP_USER_TEMPLATE=""; FP_PASS=""; continue; }
    echo
    echo "  Template username : $TPL"
    echo "  Password          : $PASS"
    yes "  Sudah benar?" && break
    FP_USER_TEMPLATE=""; FP_PASS=""
  done
  umask 077
  cat > "$DEST/.env" <<EOF
SIDECAR_TOKEN=$TOKEN
FP_HOST=resi.fastproxy.to
FP_PORT=9696
FP_PASS=$PASS
FP_USER_TEMPLATE=$TPL
FP_COUNTRY=ID
FP_ROTATE_MAX=6
CHROME_LANG=id-ID,id
EOF
  chmod 600 "$DEST/.env"
  ok ".env sidecar ditulis ($DEST/.env, izin 600)"
fi
TOKEN="$(grep -E '^SIDECAR_TOKEN=' "$DEST/.env" | tail -n1 | cut -d= -f2-)"
[ ${#TOKEN} -ge 16 ] || die "SIDECAR_TOKEN di $DEST/.env kurang dari 16 karakter."

# ---------- 4. Salin file + compose ----------
say "Menyalin file sidecar"
cp -f "$SRC/Dockerfile" "$SRC/control.js" "$DEST/"
[ -f "$SRC/README.md" ] && cp -f "$SRC/README.md" "$DEST/"
if [ -f "$SRC/update-chrome.sh" ]; then cp -f "$SRC/update-chrome.sh" "$DEST/"; chmod +x "$DEST/update-chrome.sh"; fi
cat > "$DEST/docker-compose.yml" <<EOF
services:
  fp-sidecar:
    build: .
    container_name: fp-sidecar
    restart: unless-stopped
    env_file: .env
    cap_add: [NET_ADMIN]
    devices:
      - /dev/net/tun:/dev/net/tun
    sysctls:
      net.ipv6.conf.all.disable_ipv6: "1"
      net.ipv6.conf.default.disable_ipv6: "1"
    shm_size: "1gb"
    networks:
      ptero:
        ipv4_address: $SIDE_IP

networks:
  ptero:
    name: $NET
    external: true
EOF
ok "docker-compose.yml dibuat (jaringan $NET, IP $SIDE_IP)"

# ---------- 5. Build + jalan ----------
say "Build dan jalankan (build pertama beberapa menit, mengunduh Chrome)"
( cd "$DEST" && $DC up -d --build ) || die "docker compose gagal. Lihat pesan di atas."
ok "Container dijalankan"

say "Menunggu sidecar siap (tunnel FastProxy + IP Indonesia), maksimal 10 menit"
READY=0
for i in $(seq 1 120); do
  if ! docker ps --format '{{.Names}}' | grep -qx fp-sidecar; then
    docker logs --tail 40 fp-sidecar 2>&1 | tail -n 40; die "Container fp-sidecar berhenti. Lihat log di atas."
  fi
  if docker logs fp-sidecar 2>&1 | grep -q ' siap: '; then READY=1; break; fi
  printf '.'; sleep 5
done
echo
if [ "$READY" -ne 1 ]; then
  docker logs --tail 25 fp-sidecar 2>&1
  die "Sidecar belum siap. Baca baris 'belum siap: ...' di atas (cek template/password, saldo, atau negara)."
fi
ok "$(docker logs fp-sidecar 2>&1 | grep ' siap: ' | tail -n1 | sed 's/^[^ ]* //')"

# ---------- 6. Tes otomatis ----------
say "Tes otomatis"
api() { docker exec fp-sidecar curl -s -m "${2:-20}" ${3:+-X "$3"} -H "Authorization: Bearer $TOKEN" "http://localhost:$PORT$1"; }
ST="$(api /status)"
echo "  status: $ST"
grep -q '"dns":true' <<<"$ST" && ok "UDP/DNS lewat tunnel jalan (HTTP/3 kemungkinan bisa)" || warn "dns:false = UDP lewat tunnel tidak jalan; HTTP/3 kemungkinan off (tunnel tetap aman)"

if curl -s -m 6 -H "Authorization: Bearer $TOKEN" "http://$SIDE_IP:$PORT/status" | grep -q '"ok"'; then ok "Sidecar terjangkau dari host di http://$SIDE_IP:$PORT"
else warn "Sidecar tidak terjangkau dari host di $SIDE_IP:$PORT (cek firewall host/ufw untuk $SUBNET)"; fi

docker exec fp-sidecar pkill tun2socks >/dev/null 2>&1; sleep 2
if docker exec fp-sidecar curl -s -m 6 -o /dev/null https://1.1.1.1 2>/dev/null; then
  warn "KILL-SWITCH GAGAL: Chrome masih bisa internet tanpa tunnel! Jangan dipakai, kirim hasil ini ke gw."
else ok "Kill-switch bekerja: tunnel dimatikan, internet langsung terputus"; fi
echo "  memulihkan tunnel..."
REC="$(api /ensure 170 POST)"; echo "  hasil: $REC"
grep -q '"ok":true' <<<"$REC" && ok "Tunnel pulih otomatis" || warn "Tunnel belum pulih, cek: docker logs fp-sidecar"

# ---------- 6b. Update Chrome otomatis ----------
say "Update Chrome otomatis"
if [ -x "$DEST/update-chrome.sh" ]; then
  bash "$DEST/update-chrome.sh" --check || true
  if yes "Pasang pengecekan update Chrome otomatis tiap hari jam 04:00?"; then
    if [ -d /etc/cron.d ] && { command -v cron >/dev/null 2>&1 || command -v crond >/dev/null 2>&1; }; then
      printf '# fp-sidecar: cek & update Chrome stable (rebuild hanya kalau ada versi baru dan sidecar sepi)\n0 4 * * * root /opt/fp-sidecar/update-chrome.sh >/dev/null 2>&1\n' > /etc/cron.d/fp-sidecar-update
      chmod 644 /etc/cron.d/fp-sidecar-update
      ok "Terpasang: /etc/cron.d/fp-sidecar-update (log: /var/log/fp-sidecar-update.log)"
    else
      warn "cron tidak ada di VPS ini. Pasang: apt-get install -y cron && systemctl enable --now cron, lalu jalankan pasang.sh lagi. Atau jalankan manual: bash $DEST/update-chrome.sh"
    fi
  fi
else warn "update-chrome.sh tidak ada di paket, dilewati."; fi

# ---------- 7. Pasang ke bot (opsional) ----------
say "Pasang ke bot"
URL="http://$SIDE_IP:$PORT"
mapfile -t BOTS < <(grep -ls 'WARP_REQUIRE_COUNTRY' /var/lib/pterodactyl/volumes/*/.env 2>/dev/null || true)
if [ ${#BOTS[@]} -eq 0 ]; then
  warn "File .env bot tidak ditemukan otomatis. Tambahkan 3 baris ini ke .env bot secara manual:"
else
  for ENVF in "${BOTS[@]}"; do
    BOTDIR="$(dirname "$ENVF")"
    echo "  Ditemukan bot: $BOTDIR"
    if yes "  Pasang otomatis ke bot ini (backup dibuat, bot di-restart manual dari panel)?"; then
      cp -f "$ENVF" "$ENVF.bak-pre-sidecar"
      sed -i '/^BROWSER_PROXY_MODE=/d;/^SIDECAR_URL=/d;/^SIDECAR_TOKEN=/d' "$ENVF"
      [ -n "$(tail -c1 "$ENVF")" ] && echo >> "$ENVF"
      printf 'BROWSER_PROXY_MODE=sidecar\nSIDECAR_URL=%s\nSIDECAR_TOKEN=%s\n' "$URL" "$TOKEN" >> "$ENVF"
      if [ -d "$BOTDIR/lib" ] && [ -f "$PATCH/lib/browser.js" ]; then
        [ -f "$BOTDIR/lib/browser.js.bak-pre-sidecar" ] || cp -f "$BOTDIR/lib/browser.js" "$BOTDIR/lib/browser.js.bak-pre-sidecar"
        cp -f "$PATCH/lib/browser.js" "$PATCH/lib/sidecarClient.js" "$BOTDIR/lib/"
        chown --reference="$BOTDIR/lib" "$BOTDIR/lib/browser.js" "$BOTDIR/lib/sidecarClient.js" 2>/dev/null || true
      else echo "  lib/ bot tidak diubah (tidak ada bot-patch/ di paket ini; memakai browser.js milikmu)."; fi
      chown --reference="$BOTDIR" "$ENVF" 2>/dev/null || true
      grep -qE '^ALLOW_DIRECT_IP=1' "$ENVF" && warn "  ALLOW_DIRECT_IP=1 terdeteksi di .env bot! Hapus supaya IP VPS tidak bisa dipakai."
      ok "  Bot dipasang. Backup: .env.bak-pre-sidecar dan lib/browser.js.bak-pre-sidecar"
    fi
  done
  echo "  Kalau ada bot yang dilewati, atau mau manual, tambahkan baris ini ke .env bot:"
fi
cat <<EOF

  BROWSER_PROXY_MODE=sidecar
  SIDECAR_URL=$URL
  SIDECAR_TOKEN=$TOKEN

EOF
say "Selesai. Restart server bot dari panel Pterodactyl, lalu coba plugin browser (mis. .cekdiag)."
echo "Log sidecar: docker logs -f fp-sidecar   |   Status: docker exec fp-sidecar curl -s -H 'Authorization: Bearer <token>' localhost:$PORT/status"
